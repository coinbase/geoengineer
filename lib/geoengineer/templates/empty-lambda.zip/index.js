exports.handle = function(event, context, callback) {
    console.log('empty lambda invoked')
    callback()
}
